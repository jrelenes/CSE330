Jose Elenes, Elizabeth Ramirez, Mei Lu

